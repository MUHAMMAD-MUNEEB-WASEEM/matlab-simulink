k = 15;
input;
